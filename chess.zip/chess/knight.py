import pygame
pygame.init()
square_size=40
import time
clock=pygame.time.Clock()
clock.tick(60)

class knightobj():

    def __init__(self, x, y, surface, white):
        self.x=x
        self.y=y
        self.win = surface
        self.white=white
        self.count=0
        self.isclicked=False
        self.type= "knight"
        self.oldx=x
        self.oldy=y

        if white:
            self.img = pygame.transform.scale(pygame.image.load("1xns/w_knight_1x_ns.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("1xns/b_knight_1x_ns.png"), (square_size, square_size))

    def rules(self,x,y):
        if ((abs(self.x-x)<=2 and abs(self.y-y)<=2 and (abs(self.x-x)+abs(self.y-y))==3) and not((x==self.x) and (y==self.y))):
            #add anathor if for checking valid moves(respective to other pieces on board)
            return True
        return False
        
    def draw(self):
        self.win.blit(self.img, (50*(self.x-1)+5, 50*(self.y-1)+5))

    def move(self, x , y):
        if self.rules(x, y):
            self.oldx=self.x
            self.oldy=self.y
            self.x = x
            self.y = y
            
        #self.draw()
    global count
    count=0
    #global self.isclicked
    #self.isclicked=False
    def click(self):
        #count=count
        #global count
        #global self.isclicked
        x,y=pygame.mouse.get_pos()
        #self.isclicked=False
        xfin=(x-(x%50))/50+1
        yfin=(y-(y%50))/50+1
        #print (xfin,yfin,self.isclicked)
        if pygame.mouse.get_pressed()[0]:
            self.count=self.count+1
            
            time.sleep(0.1)
            if self.count%2==1:
                if self.x==xfin and self.y==yfin:
                    self.isclicked=True
            else:
                if self.isclicked:
                    
                    self.move(xfin,yfin)
                    self.isclicked=False
                
            #print (xfin,yfin,self.x,self.y,self.isclicked,count,self.rules(xfin,yfin))
