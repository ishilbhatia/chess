import pygame
pygame.init()

square_size = 50

screen=pygame.display.set_mode((square_size*8,square_size*8))

from pieces import *

BLACK=(0,0,0)
WHITE = (255,255,255)

pos = [[None for i in range(8)] for i in range(8)]

#pices
pos[0][0] = rook(0,0,screen, True)
pos[7][0] = rook(7*square_size, 0, screen, True)
pos[0][7] = rook(0, 7*square_size, screen, False)
pos[7][7] = rook(7*square_size, 7*square_size, screen, False)
pos[0][2] = bishop(2*square_size, 0, screen, True)
pos[0][5] = bishop(5*square_size, 0, screen, True)
pos[2][7] = bishop(2*square_size,7*square_size, screen, False)
pos[5][7] = bishop(5*square_size, 7*square_size, screen, False)
pos[3][0] = queen(3*square_size, 0*square_size, screen, True)
pos[3][7] = queen(3*square_size, 7*square_size, screen, False)
pos[4][0] = king(4*square_size, 0*square_size, screen, True)
pos[4][7] = king(4*square_size, 7*square_size, screen, False)
pos[1][0] = knight(1*square_size, 0*square_size, screen, True)
pos[1][7] = knight(1*square_size, 7*square_size, screen, False)
pos[5][0] = knight(5*square_size, 0*square_size, screen, True)
pos[5][7] = knight(5*square_size, 7*square_size, screen, False)
pos[0][6] = pawn(0*square_size, 6*square_size, screen, False)



def drawBoard():
    screen.fill(WHITE)
    for i in range(8):
        if(i%2==1):
            for j in range(4):
                pygame.draw.rect(screen, BLACK, (j*2*square_size,i*square_size,square_size, square_size))
        else:
            for j in range(1,5):
                pygame.draw.rect(screen, BLACK, (j*2*square_size - square_size,i*square_size,square_size, square_size))

running=True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
    drawBoard()
    for i in range(8):
        for x in range(8):
            if pos[x][i] != None:
                pos[x][i].click()
                pos[x][i].highlight()
                pos[x][i].draw()
    
    pygame.display.update()
pygame.quit()