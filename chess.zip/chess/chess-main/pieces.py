import pygame
pygame.init()

from utils import*

square_size = 50

class rook():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-rook.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-rook.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if (((x==self.rect.x) or (y==self.rect.y)) and not((x==self.rect.x) and (y==self.rect.y))):
            #add anathor if for checking valid moves(respective to pieces on board)
            return True
        return False
    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0]:
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False

class bishop():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-bishop.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-bishop.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if (self.rect.x - x)**2 == (self.rect.y - y)**2:
            #add anathor if for checking valid moves(respective to pieces on board)
            return True
        return False
    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0] and not (pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos())):
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False

class queen():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-queen.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-queen.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if ((((x==self.rect.x) or (y==self.rect.y)) or (abs(self.rect.x-x)==abs(self.rect.y-y))) and not((x==self.rect.x) and (y==self.rect.y))):
            #add anathor if for checking valid moves(respective to pieces on board)
            return True
        return False
    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0] and not (pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos())):
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False
class knight():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-knight.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-knight.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if ((abs(self.rect.x-x)<=2*square_size and abs(self.rect.y-y)<=square_size and (abs(self.rect.x-x)+abs(self.rect.y-y))==3*square_size) and not((x==self.rect.x) and (y==self.rect.y))):
            #add anathor if for checking valid moves(respective to pieces on board)
            return True
        return False
    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0] and not (pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos())):
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False

class pawn():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False
        self.white=white

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-pawn.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-pawn.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if self.white:
            if ((self.rect.y-y==square_size and self.rect.x==x) and not((x==self.rect.x) and (y==self.rect.y))):
                #add anathor if for checking valid moves(respective to other pieces on board)
                return True
            return False
        else:
            if ((self.rect.y-y==-square_size and self.rect.x==x) and not((x==self.rect.x) and (y==self.rect.y))):
                #add anathor if for checking valid moves(respective to other pieces on board)
                return True
            return False

    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0] and not (pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos())):
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False
class king():
    def __init__(self, x, y, surface, white):
        self.win = surface
        self.rect = pygame.Rect(x, y, square_size, square_size)
        self.dragx, self.dragy  = x, y
        self.selected = False
        self.move = False

        if white:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/w-king.png"), (square_size, square_size))
        else:
            self.img = pygame.transform.scale(pygame.image.load("chess-main/images/b-king.png"), (square_size, square_size))

        

    def rules(self,x,y):
        if ((abs(self.rect.x-x)<=square_size and abs(self.rect.y-y)<=square_size) and not((x==self.rect.x) and (y==self.rect.y))):
            #add anathor if for checking valid moves(respective to other pieces on board)
            print("hi")
            return True
        return False

    
    def highlight(self):
        if self.selected:
            pygame.draw.rect(self.win, (0, 255, 0), (self.dragx, self.dragy, square_size, square_size))

    def draw(self):
        self.win.blit(self.img, self.rect)

    def click(self):
        if pygame.mouse.get_pressed()[0] and pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()) and not self.selected and not self.move:
            self.selected = True
            self.dragx, self.dragy = self.rect.x, self.rect.y

        if self.selected and not self.move:
            if pygame.mouse.get_pressed()[0] and not (pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos())):
                mousex, mousey = get_coords(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
                print(self.rect.x,self.rect.y,mousex,mousey)
                if self.rules(mousex, mousey):
                    self.rect.x, self.rect.y = mousex, mousey
                    self.move = True
                    

        if self.move and self.selected:
            if not pygame.mouse.get_pressed()[0] and not pygame.Rect.collidepoint(self.rect, pygame.mouse.get_pos()):
                self.move = False
                self.selected = False
        #print (self.move)