from rook import *
r1=rookobj(10,10)
print (r1.rules(80,10))
print(pygame.mouse.get_pressed())