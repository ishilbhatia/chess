
import pygame
from rook import *
from bishop import *
from queen import *
from knight import *
from king import *
from pawn import *
import time
clock=pygame.time.Clock()
clock.tick(60)
count=0

#rookimg=pygame.image.load('wpawn.png')
#rookimgscaled=pygame.transform.scale(rookimg,(60,60))

pygame.init()

square_size = 50

screen=pygame.display.set_mode((square_size*8,square_size*8))

BLACK=(73,172,42)
WHITE = (255,255,255)

r1=rookobj(1,8,screen,True)
b1=bishopobj(2,8,screen,True)
q1=queenobj(3,8,screen,True)
n1=knightobj(4,8,screen,True)
k1=kingobj(5,8,screen,True)
p1=pawnobj(6,2,screen,True)
dummy=bishopobj(9,8,screen,True)
pieces=[dummy,r1,b1,q1,n1,k1,p1]
def drawBoard():
    screen.fill(WHITE)
    for i in range(8):
        if(i%2==1):
            for j in range(4):
                pygame.draw.rect(screen, BLACK, (j*2*square_size,i*square_size,square_size, square_size))
        else:
            for j in range(5):
                pygame.draw.rect(screen, BLACK, (j*2*square_size - square_size,i*square_size,square_size, square_size))

running=True
while running:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
    
    drawBoard()
    #if pygame.MOUSEBUTTONDOWN:
     #   print(pygame.mouse.get_pos())
    if p1.__getattribute__('y')==8 and p1.__getattribute__('type')=='pawn':
        p1=queenobj(p1.__getattribute__('x'),8,screen,False)

    if p1.__getattribute__('y')==1 and p1.__getattribute__('type')=='pawn':
        b=0
        p1.__setattr__('y',1000)
        
        p1=queenobj(p1.__getattribute__('x'),1,screen,True)
        for i in range(1,len(pieces)):
            if pieces[i]==p1:
                #pieces[i]=p1
                break
        pieces[b]=p1
        

    #if pygame.mouse.get_pressed()[0]:
     #   count=count+1
    for i in pieces:
        i.click()
        if i.__getattribute__('x')>i.__getattribute__('oldx'):
            if i.__getattribute__('y')>i.__getattribute__('oldy'):
                for j in range(i.__getattribute__('oldx'),i.__getattribute__('x')):
                    for k in range(i.__getattribute__('oldy'),i.__getattribute__('y')):
                        for l in pieces:
                            if i.x==j and i.y==k:
                                i.__setattr__('x',i.oldx)
                                i.oldy=i.y
            else:
                for j in range(i.__getattribute__('oldx'),i.__getattribute__('x')):
                    for k in range(i.__getattribute__('y'),i.__getattribute__('oldy'),-1):
                        for l in pieces:
                            if i.x==j and i.y==k:
                                i.__setattr__('x',i.oldx)
                                i.oldy=i.y
        else:
            if i.__getattribute__('y')>i.__getattribute__('oldy'):
                for j in range(i.__getattribute__('x'),i.__getattribute__('oldx'),-1):
                    for k in range(i.__getattribute__('oldy'),i.__getattribute__('y')):
                        for l in pieces:
                            if i.x==j and i.y==k:
                                i.__setattr__('x',i.oldx)
                                i.oldy=i.y
            else:
                for j in range(i.__getattribute__('x'),i.__getattribute__('oldx'),-1):
                    for k in range(i.__getattribute__('y'),i.__getattribute__('oldy'),-1):
                        for l in pieces:
                            if i.x==j and i.y==k:
                                i.__setattr__('x',i.oldx)
                                i.oldy=i.y

        
    for i in pieces:
        i.draw()
    #print(r1.__getattribute__('y'))
    #r1.draw()
    
    #print(pygame.mouse.get_pressed())
    pygame.display.update()
    
pygame.quit()